import { BadgecountDirective } from './badgecount.directive';

describe('BadgecountDirective', () => {
  it('should create an instance', () => {
    const directive = new BadgecountDirective();
    expect(directive).toBeTruthy();
  });
});
